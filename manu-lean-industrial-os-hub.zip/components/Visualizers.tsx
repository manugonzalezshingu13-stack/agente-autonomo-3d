
import React, { useMemo, useState } from 'react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, 
  Line, LineChart, Cell
} from 'recharts';
import * as Icons from 'lucide-react';

interface DiagramHeaderProps {
  title: string;
  purpose: string;
  leanRelevance: string;
  dataImpact: string;
}

const UsageGuideModal: React.FC<{ 
  isOpen: boolean; 
  onClose: () => void; 
  title: string; 
  purpose: string; 
  leanRelevance: string; 
  dataImpact: string; 
}> = ({ isOpen, onClose, title, purpose, leanRelevance, dataImpact }) => {
  if (!isOpen) return null;
  return (
    <div className="fixed inset-0 z-[100] flex items-center justify-center p-6 bg-slate-950/40 backdrop-blur-sm animate-in fade-in duration-300">
      <div className="bg-white w-full max-w-2xl rounded-[3rem] shadow-2xl overflow-hidden border border-slate-100 animate-in zoom-in-95 duration-300">
        <div className="bg-slate-900 p-8 text-white flex justify-between items-center">
          <div>
            <h2 className="text-2xl font-black tracking-tighter uppercase">{title}</h2>
            <p className="text-blue-400 text-[10px] font-black uppercase tracking-[0.3em] mt-1">Industrial Execution Guide</p>
          </div>
          <button onClick={onClose} className="p-3 hover:bg-white/10 rounded-full transition-colors">
            <Icons.X size={24} />
          </button>
        </div>
        <div className="p-10 space-y-8 max-h-[70vh] overflow-y-auto scrollbar-hide">
          <section className="space-y-3">
            <h4 className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-blue-600">
              <Icons.Target size={18} /> Propósito Operativo
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed font-medium">{purpose}</p>
          </section>
          <div className="h-px bg-slate-100" />
          <section className="space-y-3">
            <h4 className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-emerald-600">
              <Icons.Zap size={18} /> Relevancia Lean (Muda Reduction)
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed font-medium">{leanRelevance}</p>
          </section>
          <div className="h-px bg-slate-100" />
          <section className="space-y-3">
            <h4 className="flex items-center gap-3 text-xs font-black uppercase tracking-widest text-amber-600">
              <Icons.Database size={18} /> Impacto en Arquitectura de Datos
            </h4>
            <p className="text-sm text-slate-600 leading-relaxed font-medium">{dataImpact}</p>
          </section>
        </div>
        <div className="p-8 bg-slate-50 border-t flex justify-end">
          <button onClick={onClose} className="px-8 py-3 bg-slate-900 text-white rounded-2xl font-black text-xs uppercase tracking-widest hover:bg-black transition-colors">Entendido</button>
        </div>
      </div>
    </div>
  );
};

const DiagramHeader: React.FC<DiagramHeaderProps> = ({ title, purpose, leanRelevance, dataImpact }) => {
  const [isGuideOpen, setIsGuideOpen] = useState(false);
  return (
    <div className="flex items-center justify-between mb-6 group/header relative">
      <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-400 flex items-center gap-2">
        <div className="w-1 h-4 bg-blue-600 rounded-full" />
        {title}
      </h3>
      <button 
        onClick={() => setIsGuideOpen(true)}
        className="flex items-center gap-2 px-4 py-2 bg-slate-100 hover:bg-blue-600 text-slate-500 hover:text-white rounded-xl transition-all font-black text-[10px] uppercase tracking-widest shadow-sm"
      >
        <Icons.BookOpen size={14} /> Guía de Uso
      </button>
      <UsageGuideModal 
        isOpen={isGuideOpen} 
        onClose={() => setIsGuideOpen(false)} 
        title={title}
        purpose={purpose}
        leanRelevance={leanRelevance}
        dataImpact={dataImpact}
      />
    </div>
  );
};

const MetadataBadge: React.FC<{ label: string; value: any }> = ({ label, value }) => (
  <div className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded bg-slate-100 text-[10px] text-slate-500 border border-slate-200">
    <span className="font-bold uppercase opacity-60">{label}:</span>
    <span className="truncate max-w-[80px]">{String(value)}</span>
  </div>
);

// --- Neural Flow Visualizer ---
export const NeuralFlowVisualizer: React.FC<{ data?: any }> = ({ data }) => {
  const defaultNodes = [
    { id: 1, x: 100, y: 250, label: 'ERP / Demand', type: 'source' },
    { id: 2, x: 300, y: 150, label: 'MES Control', type: 'process' },
    { id: 3, x: 300, y: 350, label: 'SCADA Layer', type: 'process' },
    { id: 4, x: 500, y: 100, label: 'Line A Data', type: 'data' },
    { id: 5, x: 500, y: 250, label: 'Line B Data', type: 'data' },
    { id: 6, x: 500, y: 400, label: 'Quality Check', type: 'data' },
    { id: 7, x: 750, y: 250, label: 'KPI Engine', type: 'output' },
  ];

  const defaultEdges = [
    { from: 1, to: 2 }, { from: 1, to: 3 },
    { from: 2, to: 4 }, { from: 2, to: 5 },
    { from: 3, to: 5 }, { from: 3, to: 6 },
    { from: 4, to: 7 }, { from: 5, to: 7 }, { from: 6, to: 7 },
  ];

  const nodes = data?.nodes || defaultNodes;
  const edges = data?.edges || defaultEdges;

  return (
    <div className="relative w-full h-[600px] bg-slate-950 rounded-[4rem] overflow-hidden border border-slate-800 shadow-[0_0_100px_rgba(0,0,0,0.5)] flex items-center justify-center group">
      <div className="absolute inset-0 opacity-20 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:40px_40px] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_50%,#000_70%,transparent_100%)] transform perspective-1000 rotate-x-12 animate-pulse" />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[400px] bg-blue-600/10 blur-[120px] rounded-full pointer-events-none" />

      <svg className="w-full h-full relative z-10" viewBox="0 0 900 600">
        <defs>
          <filter id="neural-glow" x="-50%" y="-50%" width="200%" height="200%">
            <feGaussianBlur stdDeviation="4" result="blur" />
            <feComposite in="SourceGraphic" in2="blur" operator="over" />
          </filter>
          <linearGradient id="link-grad" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#1e293b" />
            <stop offset="50%" stopColor="#3b82f6" />
            <stop offset="100%" stopColor="#1e293b" />
          </linearGradient>
        </defs>

        {edges.map((edge: any, i: number) => {
          const fromNode = nodes.find((n: any) => n.id === (edge.from || edge.source));
          const toNode = nodes.find((n: any) => n.id === (edge.to || edge.target));
          if (!fromNode || !toNode) return null;
          return (
            <g key={`edge-${i}`} className="opacity-40 group-hover:opacity-100 transition-opacity duration-1000">
              <path d={`M ${fromNode.x} ${fromNode.y} C ${(fromNode.x + toNode.x)/2} ${fromNode.y}, ${(fromNode.x + toNode.x)/2} ${toNode.y}, ${toNode.x} ${toNode.y}`} stroke="url(#link-grad)" strokeWidth="1.5" fill="none" />
              {[1, 2, 3].map((p) => (
                <circle key={p} r={1.5 + p*0.5} fill={p === 3 ? "#10b981" : "#60a5fa"} filter="url(#neural-glow)">
                  <animateMotion dur={`${1.5 + p + Math.random() * 2}s`} repeatCount="indefinite" begin={`${p * 0.5}s`} path={`M ${fromNode.x} ${fromNode.y} C ${(fromNode.x + toNode.x)/2} ${fromNode.y}, ${(fromNode.x + toNode.x)/2} ${toNode.y}, ${toNode.x} ${toNode.y}`} />
                </circle>
              ))}
            </g>
          );
        })}

        {nodes.map((node: any, i: number) => {
          const color = node.type === 'source' ? '#3b82f6' : node.type === 'output' ? '#10b981' : '#8b5cf6';
          return (
            <g key={`node-${i}`} className="cursor-pointer group/node">
              <circle cx={node.x} cy={node.y} r="25" fill={color} fillOpacity="0.05" className="transition-all duration-500 group-hover/node:fill-opacity-20" />
              <circle cx={node.x} cy={node.y} r="10" fill={color} filter="url(#neural-glow)" className="animate-pulse" />
              <circle cx={node.x} cy={node.y} r="14" fill="none" stroke={color} strokeWidth="1" strokeDasharray="4 4" className="animate-spin-slow opacity-40 group-hover/node:opacity-100 transition-opacity" />
              <text x={node.x} y={node.y + 45} textAnchor="middle" fill="white" className="text-[10px] font-black uppercase tracking-[0.2em] transition-all group-hover/node:fill-blue-400">{node.label || node.id}</text>
            </g>
          );
        })}
      </svg>
      <div className="absolute top-10 left-10"><div className="flex items-center gap-3 bg-white/5 backdrop-blur-md px-6 py-3 rounded-full border border-white/10 shadow-2xl"><div className="w-2 h-2 bg-emerald-500 rounded-full animate-ping" /><span className="text-[10px] font-black text-white uppercase tracking-widest">Neural Link Active</span></div></div>
      <div className="absolute inset-0 pointer-events-none border-[32px] border-slate-950 opacity-40 rounded-[4rem]" />
    </div>
  );
};

export const SkeletonLoader: React.FC = () => (
  <div className="w-full space-y-8 animate-pulse p-4">
    <div className="flex gap-4"><div className="h-24 w-2/3 bg-slate-100 rounded-3xl" /><div className="h-24 w-1/3 bg-slate-100 rounded-3xl" /></div>
    <div className="h-[400px] w-full bg-slate-50 rounded-3xl border border-slate-100" />
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">{[1, 2, 3, 4].map(i => (<div key={i} className="h-32 bg-slate-50 rounded-2xl border border-slate-100" />))}</div>
  </div>
);

// 1. ERD Visualizer
export const ErdVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { entities = [], relations = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="Metadata Entity-Relationship" purpose="Mapeo de la estructura de datos industrial." leanRelevance="Elimina silos de información." dataImpact="Asegura linaje de datos." />
      <div className="p-4 bg-slate-50 rounded-2xl overflow-x-auto min-h-[500px] relative">
        <div className="flex flex-wrap gap-8 justify-center pb-20">
          {entities.map((ent: any, i: number) => (
            <div key={i} className="w-60 bg-white border border-indigo-200 rounded-xl shadow-xl overflow-hidden hover:border-indigo-500 transition-all hover:-translate-y-1">
              <div className="bg-indigo-600 p-3 text-white text-center font-black text-[10px] uppercase tracking-widest"><Icons.Database size={14} className="inline mr-2" />{ent.name}</div>
              <div className="p-3 space-y-1.5">{ent.fields?.map((f: any, j: number) => (<div key={j} className="flex justify-between text-[11px] py-1.5 border-b border-slate-50 font-medium"><span>{f.name}</span><span className="text-slate-400 italic font-mono text-[9px]">{f.type}</span></div>))}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 2. State Visualizer
export const StateVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { states = [], transitions = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="Industrial Lifecycle State Machine" purpose="Modela transiciones lógicas de activos." leanRelevance="Identifica cuellos de botella." dataImpact="Previene corrupción de estados." />
      <div className="p-10 bg-slate-950 rounded-[3rem] min-h-[500px] relative overflow-hidden shadow-2xl border border-slate-800">
        <div className="flex flex-wrap gap-10 justify-center mb-20">{states.map((s: string, i: number) => (<div key={i} className="px-10 py-6 bg-slate-900 border-2 border-emerald-500/40 rounded-[2rem] text-emerald-400 font-black text-xs uppercase tracking-widest animate-pulse">{s}</div>))}</div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">{transitions.map((t: any, i: number) => (<div key={i} className="p-5 bg-slate-900/60 border border-slate-800 rounded-3xl text-[10px] font-black text-slate-500 uppercase flex flex-col gap-2"><div>{t.from} -> {t.to}</div><div className="text-emerald-400 border border-emerald-500/20 p-2 rounded-xl bg-emerald-500/5">{t.trigger}</div></div>))}</div>
      </div>
    </div>
  );
};

// 3. Data Profiling Visualizer (Enhanced with Filter & Sort)
export const DataProfilingVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { metrics = [], sampleSize = 0 } = data;
  const [filter, setFilter] = useState<string>('All');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

  const filteredMetrics = useMemo(() => {
    let result = [...metrics];
    if (filter !== 'All') {
      result = result.filter(m => m.category.toLowerCase().includes(filter.toLowerCase()));
    }
    result.sort((a, b) => sortOrder === 'desc' ? b.score - a.score : a.score - b.score);
    return result;
  }, [metrics, filter, sortOrder]);

  const avgHealth = metrics.length > 0 ? Math.round(metrics.reduce((acc: number, curr: any) => acc + curr.score, 0) / metrics.length) : 0;

  return (
    <div className="space-y-10">
      <DiagramHeader title="Industrial Data Quality Health" purpose="Métricas de salud del dato industrial." leanRelevance="Elimina desperdicio de información defectuosa." dataImpact="Base para analítica predictiva." />
      
      {/* Metrics Controls */}
      <div className="flex flex-col md:flex-row items-center justify-between gap-6 bg-slate-50 p-6 rounded-[2rem] border border-slate-200">
        <div className="flex items-center gap-4">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Filtrar por:</span>
          <div className="flex gap-2">
            {['All', 'Integridad', 'Precisión', 'Consistencia', 'Puntualidad'].map(cat => (
              <button 
                key={cat} 
                onClick={() => setFilter(cat)} 
                className={`px-4 py-2 rounded-xl text-[10px] font-black transition-all ${filter === cat ? 'bg-blue-600 text-white shadow-lg' : 'bg-white text-slate-500 hover:bg-slate-100 border'}`}
              >
                {cat}
              </button>
            ))}
          </div>
        </div>
        <div className="flex items-center gap-4">
          <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Orden:</span>
          <button 
            onClick={() => setSortOrder(sortOrder === 'desc' ? 'asc' : 'desc')} 
            className="flex items-center gap-2 px-4 py-2 bg-white rounded-xl text-[10px] font-black border hover:bg-slate-100 transition-colors"
          >
            {sortOrder === 'desc' ? <Icons.ArrowDownWideNarrow size={14} /> : <Icons.ArrowUpWideNarrow size={14} />}
            {sortOrder === 'desc' ? 'Puntaje Alto' : 'Puntaje Bajo'}
          </button>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        <div className="col-span-1 md:col-span-2 p-8 bg-blue-950 rounded-[2.5rem] shadow-2xl flex items-center justify-between">
          <div className="flex items-center gap-8">
            <div className="p-5 bg-blue-600 rounded-3xl text-white shadow-2xl"><Icons.Database size={40} /></div>
            <div>
              <h5 className="text-[10px] font-black text-blue-400 uppercase tracking-widest mb-2">Muestra de Análisis</h5>
              <p className="text-5xl font-black text-white">{sampleSize.toLocaleString()} <span className="text-xs font-normal text-blue-400 uppercase">Regs</span></p>
            </div>
          </div>
        </div>
        <div className="p-8 bg-white border border-slate-100 rounded-[2.5rem] shadow-xl flex flex-col items-center justify-center">
           <div className="relative flex items-center justify-center">
              <svg className="w-32 h-32 transform -rotate-90">
                <circle cx="64" cy="64" r="56" stroke="#f1f5f9" strokeWidth="12" fill="transparent" />
                <circle cx="64" cy="64" r="56" stroke="#10b981" strokeWidth="12" fill="transparent" strokeDasharray={351.8} strokeDashoffset={351.8 - (351.8 * avgHealth) / 100} strokeLinecap="round" />
              </svg>
              <div className="absolute text-3xl font-black text-slate-800">{avgHealth}%</div>
           </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-2xl">
          <ResponsiveContainer width="100%" height={320}>
            <BarChart data={filteredMetrics} layout="vertical">
              <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#f8fafc" />
              <XAxis type="number" domain={[0, 100]} fontSize={10} stroke="#cbd5e1" />
              <YAxis dataKey="category" type="category" width={110} fontSize={10} stroke="#64748b" tick={{ fontWeight: 800 }} />
              <Tooltip cursor={{fill: '#f1f5f9'}} />
              <Bar dataKey="score" radius={[0, 20, 20, 0]} barSize={24}>
                {filteredMetrics.map((entry: any, index: number) => (
                  <Cell key={`cell-${index}`} fill={entry.score > 85 ? '#10b981' : '#3b82f6'} />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
          {filteredMetrics.map((m: any, i: number) => (
            <div key={i} className="p-6 bg-white border border-slate-100 rounded-[2rem] shadow-sm hover:shadow-2xl transition-all">
              <div className="flex items-center gap-3 mb-5">
                <div className={`p-2 rounded-xl ${m.score > 85 ? 'bg-emerald-50 text-emerald-600' : 'bg-rose-50 text-rose-600'}`}><Icons.CheckCircle size={18} /></div>
                <h6 className="text-[10px] font-black uppercase text-slate-800">{m.category}</h6>
              </div>
              <div className="space-y-2">
                {m.issues?.map((issue: string, j: number) => (
                  <div key={j} className="text-[11px] text-slate-500 flex items-start gap-2 font-semibold"><div className="mt-1.5 w-1 h-1 bg-slate-300 rounded-full shrink-0" /> {issue}</div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

// 4. Sequence Visualizer
export const SequenceVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { lifelines = [], messages = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="UML Interaction Sequence" purpose="Interacción cronológica sistemas-humanos." leanRelevance="Detecta latencias de interacción." dataImpact="Optimiza flujos de procesamiento." />
      <div className="p-8 bg-white rounded-3xl overflow-x-auto min-h-[500px]">
        <div className="min-w-[900px] relative">
          <div className="flex justify-around mb-16">{lifelines.map((ll: any, i: number) => (<div key={i} className="flex flex-col items-center"><div className="p-4 bg-slate-900 text-white rounded-2xl font-black text-[10px] uppercase min-w-[120px] text-center border-b-4 border-blue-600">{ll.name}</div><div className="w-px h-[400px] border-dashed border-l-2 border-slate-200 mt-2" /></div>))}</div>
          <div className="absolute top-24 left-0 right-0 space-y-10">{messages.map((m: any, i: number) => (<div key={i} className="relative h-px bg-blue-500/40 mx-20"><div className="absolute right-0 -top-1 border-y-4 border-y-transparent border-l-8 border-l-blue-600" /><div className="text-[10px] font-black text-blue-700 bg-white px-3 py-1 rounded-full border absolute -top-4 left-1/2 -translate-x-1/2 shadow-sm uppercase">{m.text}</div></div>))}</div>
        </div>
      </div>
    </div>
  );
};

// 5. Pareto Visualizer
export const ParetoVisualizer: React.FC<{ data: any[] }> = ({ data }) => {
  const sortedData = [...data].sort((a, b) => b.value - a.value);
  const total = sortedData.reduce((sum, item) => sum + item.value, 0);
  let cumulative = 0;
  const chartData = sortedData.map(item => { cumulative += item.value; return { ...item, percentage: Math.round((cumulative / total) * 100) }; });
  return (
    <div className="space-y-8">
      <DiagramHeader title="Pareto Distribution Chart" purpose="Priorización de problemas (80/20)." leanRelevance="Maximiza ROI en proyectos Kaizen." dataImpact="Enfoca corrección de datos críticos." />
      <div className="h-[400px] w-full bg-white p-6 rounded-3xl border border-slate-100 shadow-xl">
        <ResponsiveContainer width="100%" height="100%">
          <BarChart data={chartData}>
            <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
            <XAxis dataKey="name" fontSize={10} axisLine={false} tickLine={false} />
            <YAxis yAxisId="left" fontSize={10} axisLine={false} tickLine={false} />
            <YAxis yAxisId="right" orientation="right" domain={[0, 100]} fontSize={10} axisLine={false} tickLine={false} />
            <Tooltip />
            <Bar yAxisId="left" dataKey="value" fill="#3b82f6" radius={[6, 6, 0, 0]} barSize={40} />
            <Line yAxisId="right" type="monotone" dataKey="percentage" stroke="#ef4444" strokeWidth={4} />
          </BarChart>
        </ResponsiveContainer>
      </div>
    </div>
  );
};

// 6. Ishikawa Visualizer
export const IshikawaVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { mainProblem, causes = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="Ishikawa / Fishbone Diagram" purpose="Análisis de causa raíz multidimensional." leanRelevance="Pieza clave del ciclo PDCA." dataImpact="Mapea variabilidad de fuentes de datos." />
      <div className="p-10 border rounded-[2.5rem] bg-white shadow-2xl overflow-x-auto min-h-[500px] relative">
        <div className="relative min-w-[1000px] h-[400px]">
          <div className="absolute top-1/2 left-0 right-72 h-2 bg-slate-900 rounded-full" />
          <div className="absolute top-1/2 right-0 -translate-y-1/2 w-64 h-32 border-4 border-slate-900 flex flex-col items-center justify-center bg-blue-900 text-white font-black text-center px-6 rounded-3xl shadow-2xl uppercase text-xs">{mainProblem}</div>
          {causes.map((c: any, i: number) => {
            const isTop = i % 2 === 0;
            return (
              <div key={i} className="absolute flex flex-col items-center" style={{ left: `${(i) * 15 + 10}%`, [isTop ? 'bottom' : 'top']: '50%', height: '40%' }}>
                <div className="h-full w-1 bg-slate-200 relative">
                  <div className={`absolute ${isTop ? '-top-10' : '-bottom-10'} font-black text-blue-900 uppercase text-[10px] bg-white px-3 py-1 border-2 border-slate-900 rounded-xl`}>{c.category}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};

// 7. Kanban Visualizer
export const KanbanVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const columns = { todo: data.tasks?.filter((t: any) => t.status === 'todo') || [], doing: data.tasks?.filter((t: any) => t.status === 'doing') || [], done: data.tasks?.filter((t: any) => t.status === 'done') || [] };
  const labels = { todo: 'To Do', doing: 'In Progress', done: 'Done' };
  return (
    <div className="space-y-6">
      <DiagramHeader title="Visual Flow Control (Kanban)" purpose="Gestión visual de WIP." leanRelevance="Implementa sistema Pull." dataImpact="Controla pipelines de datos." />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
        {Object.entries(columns).map(([k, tasks]) => (
          <div key={k} className="bg-slate-50 p-6 rounded-[2rem] min-h-[500px] border border-slate-100">
            <h3 className="font-black mb-6 text-slate-800 text-xs uppercase tracking-widest flex justify-between"><span>{labels[k as keyof typeof labels]}</span><span className="bg-white px-2 py-1 rounded-full border">{tasks.length}</span></h3>
            <div className="space-y-4">{tasks.map((t: any, i: number) => (<div key={i} className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 font-bold text-sm">{t.title}</div>))}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 8. Process Flow Visualizer
export const ProcessFlowVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { nodes = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="Industrial Process Topology" purpose="Flujo físico y lógico de materiales." leanRelevance="Detecta muda de transporte." dataImpact="Mapa de latencia de nodos." />
      <div className="p-10 bg-slate-950 rounded-[2.5rem] min-h-[500px] shadow-2xl relative overflow-x-auto">
        <div className="relative min-w-[900px] h-[300px]">{nodes.map((n: any, i: number) => (<div key={n.id} className="absolute w-44 p-5 bg-slate-900 border border-slate-800 rounded-3xl text-white font-black text-xs uppercase" style={{ left: 20 + i * 220, top: 100 }}>{n.label}<div className="mt-2 text-[9px] text-blue-400">{n.type}</div></div>))}</div>
      </div>
    </div>
  );
};

// 9. SIPOC Visualizer
export const SipocVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const elements = data.elements || [];
  const labels = { S: 'Suppliers', I: 'Inputs', P: 'Process', O: 'Outputs', C: 'Customers' };
  return (
    <div className="space-y-6">
      <DiagramHeader title="SIPOC Strategic Map" purpose="Definición macro del alcance del proceso." leanRelevance="Delimita proyectos Six Sigma." dataImpact="Mapa de fuentes y destinos de datos." />
      <div className="grid grid-cols-5 gap-4">
        {Object.entries(labels).map(([k, l]) => (
          <div key={k} className="space-y-4">
            <div className="p-4 bg-slate-900 text-white text-center font-black rounded-2xl text-[10px] uppercase tracking-widest">{l}</div>
            <div className="space-y-2">{elements.filter((e: any) => e.type === k).map((item: any, i: number) => (<div key={i} className="p-4 bg-white border rounded-2xl text-[11px] font-bold shadow-sm">{item.label}</div>))}</div>
          </div>
        ))}
      </div>
    </div>
  );
};

// 10. Class Visualizer
export const ClassVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { classes = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="UML Domain Objects Chart" purpose="Estructuración de objetos digitales." leanRelevance="Asegura escalabilidad técnica." dataImpact="Contrato de metadatos robusto." />
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8">{classes.map((cls: any, i: number) => (<div key={i} className="bg-white border-2 border-slate-900 rounded-3xl overflow-hidden hover:-translate-y-1 transition-transform"><div className="bg-slate-900 p-4 text-center font-black uppercase text-white text-xs">{cls.name}</div><div className="p-4 space-y-2">{cls.attributes?.map((a: string, j: number) => (<div key={j} className="text-[11px] text-slate-700 flex items-center gap-2 font-medium"><div className="w-1 h-1 bg-blue-500 rounded-full" /> {a}</div>))}</div></div>))}</div>
    </div>
  );
};

// 11. Observability Visualizer
export const ObservabilityVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { gauges = [] } = data;
  return (
    <div className="space-y-6">
      <DiagramHeader title="Industrial Observability Telemetry" purpose="Monitoreo de infraestructura de datos." leanRelevance="Implementa Jidoka digital." dataImpact="Asegura disponibilidad del pipeline." />
      <div className="grid grid-cols-2 md:grid-cols-4 gap-6">{gauges.map((g: any, i: number) => (<div key={i} className="p-8 bg-slate-900 rounded-[2.5rem] border border-slate-800 flex flex-col items-center text-center"><div className="text-[10px] font-black uppercase text-slate-500 mb-4 tracking-widest">{g.label}</div><div className={`text-4xl font-black mb-2 ${g.status === 'crit' ? 'text-rose-500' : 'text-emerald-400'}`}>{g.current}</div><div className="w-full h-1 bg-slate-800 rounded-full mt-4"><div className={`h-full bg-blue-500 transition-all duration-1000`} style={{ width: `${(g.current / g.limit) * 100}%` }} /></div></div>))}</div>
    </div>
  );
};

// 12. Network Topology Visualizer (Enhanced for IT/OT)
export const NetworkTopologyVisualizer: React.FC<{ data: any }> = ({ data }) => {
  const { nodes = [], edges = [] } = data;
  const getIconForType = (type: string) => {
    const t = type?.toLowerCase();
    if (t?.includes('firewall')) return <Icons.ShieldCheck size={16} />;
    if (t?.includes('server')) return <Icons.Server size={16} />;
    if (t?.includes('plc')) return <Icons.Cpu size={16} />;
    if (t?.includes('hmi')) return <Icons.Layout size={16} />;
    if (t?.includes('sensor')) return <Icons.Radio size={16} />;
    if (t?.includes('cloud')) return <Icons.Cloud size={16} />;
    return <Icons.Network size={16} />;
  };

  const getStatusColor = (status: string) => {
    const s = status?.toLowerCase();
    if (s === 'crit') return 'text-rose-500 bg-rose-500/10 border-rose-500/30 shadow-[0_0_15px_rgba(244,63,94,0.3)]';
    if (s === 'warn') return 'text-amber-500 bg-amber-500/10 border-amber-500/30';
    return 'text-emerald-400 bg-emerald-400/10 border-emerald-400/30 shadow-[0_0_15px_rgba(52,211,153,0.3)]';
  };

  return (
    <div className="space-y-6">
      <DiagramHeader title="IT/OT Network Topology Map" purpose="Mapeo de infraestructura crítica industrial." leanRelevance="Identifica redundancias innecesarias." dataImpact="Asegura transporte de datos en tiempo real." />
      <div className="relative w-full h-[650px] bg-slate-950 rounded-[4rem] overflow-hidden border border-slate-800 shadow-2xl group">
        <div className="absolute inset-0 opacity-5 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:50px_50px]" />
        
        <svg className="w-full h-full relative z-10" viewBox="0 0 1000 650">
          <defs>
            <marker id="arrow-industrial" markerWidth="8" markerHeight="6" refX="15" refY="3" orient="auto">
              <polygon points="0 0, 8 3, 0 6" fill="#1e293b" />
            </marker>
          </defs>

          {/* Edges with Data Flow Particles */}
          {edges.map((edge: any, i: number) => {
            const from = nodes.find((n: any) => n.id === edge.from);
            const to = nodes.find((n: any) => n.id === edge.to);
            if (!from || !to) return null;
            const fx = from.x || 100 + (i * 150) % 800;
            const fy = from.y || 100 + (Math.floor(i / 2) * 200) % 500;
            const tx = to.x || 200 + (i * 150) % 800;
            const ty = to.y || 200 + (Math.floor(i / 2) * 200) % 500;

            return (
              <g key={`net-edge-${i}`}>
                <line x1={fx} y1={fy} x2={tx} y2={ty} stroke="#1e293b" strokeWidth="2" markerEnd="url(#arrow-industrial)" />
                <circle r="2.5" fill="#3b82f6" className="filter blur-[1px]">
                  <animateMotion dur={`${2 + Math.random() * 2}s`} repeatCount="indefinite" path={`M ${fx} ${fy} L ${tx} ${ty}`} />
                </circle>
              </g>
            );
          })}

          {/* Specialized Network Nodes */}
          {nodes.map((node: any, i: number) => {
            const x = node.x || 100 + (i * 150) % 800;
            const y = node.y || 100 + (Math.floor(i / 2) * 200) % 500;
            const statusClass = getStatusColor(node.status);

            return (
              <foreignObject key={`net-node-${i}`} x={x - 65} y={y - 50} width="130" height="120">
                <div className="flex flex-col items-center gap-3">
                  <div className={`p-4 rounded-3xl border transition-all hover:scale-125 cursor-help ${statusClass}`}>
                    {getIconForType(node.type)}
                  </div>
                  <div className="text-center">
                    <div className="text-[10px] font-black text-white uppercase tracking-tighter w-24 truncate">{node.label}</div>
                    <div className="flex items-center justify-center gap-1.5 mt-1">
                      <div className={`w-1 h-1 rounded-full animate-pulse ${node.status === 'crit' ? 'bg-rose-500' : 'bg-emerald-400'}`} />
                      <span className="text-[8px] font-mono text-slate-500 tracking-tighter">{node.latency}ms</span>
                    </div>
                  </div>
                </div>
              </foreignObject>
            );
          })}
        </svg>

        {/* Legend */}
        <div className="absolute top-10 right-10 flex flex-col gap-3 bg-slate-900/80 backdrop-blur-md p-6 rounded-[2rem] border border-white/5 shadow-2xl">
          <div className="text-[9px] font-black text-slate-400 uppercase tracking-[0.3em] mb-1">Network Zones</div>
          <div className="flex items-center gap-3 text-[10px] font-black text-white"><div className="w-2 h-2 rounded-full bg-blue-500" /> IT / Management</div>
          <div className="flex items-center gap-3 text-[10px] font-black text-white"><div className="w-2 h-2 rounded-full bg-amber-500" /> DMZ / Perimeter</div>
          <div className="flex items-center gap-3 text-[10px] font-black text-white"><div className="w-2 h-2 rounded-full bg-emerald-500" /> OT / Field Layer</div>
        </div>
      </div>
    </div>
  );
};
