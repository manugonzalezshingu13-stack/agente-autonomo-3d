
import { GoogleGenAI, Type } from "@google/genai";

export class IndustrialAI {
  private ai: GoogleGenAI;

  constructor() {
    this.ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }

  async generateToolData(toolId: string, context: string) {
    const response = await this.ai.models.generateContent({
      model: "gemini-3-pro-preview",
      contents: `Genera una arquitectura de DATOS e INFORMACIÓN experta para la herramienta "${toolId}" aplicada a: "${context}".
      
      ESTÁNDARES REQUERIDOS:
      - Para ERD: Debes definir OBLIGATORIAMENTE las entidades: "Proceso", "Paso", "Punto de Datos" y "Métrica".
      - Para DATA-PROFILING: Visualiza métricas de "Integridad", "Precisión", "Consistencia" y "Puntualidad".
      - Para STATE-DIAG: Modela el ciclo de vida crítico.
      - Para NETWORK-TOPO: Genera una red IT/OT robusta. Incluye:
        * Nodos IT: 'firewall_edge', 'server_erp', 'cloud_aws'.
        * Nodos OT: 'firewall_industrial', 'plc_master', 'hmi_station', 'iiot_sensor'.
        * Propiedades: status ('ok', 'warn', 'crit'), latency (en ms), x/y coordinates para una disposición lógica (Zonas ISA-95).
      
      ESTRUCTURAS JSON REQUERIDAS:
      - sequence: { lifelines: { name: string, type: string }[], messages: { from: string, to: string, text: string }[] }
      - uml-class: { classes: { name: string, attributes: string[], methods: string[] }[] }
      - erd: { entities: { name: string, fields: { name: string, type: string, key?: 'PK'|'FK' }[] }[], relations: { from: string, to: string }[] }
      - data-profiling: { metrics: { category: string, score: number, issues: string[] }[], sampleSize: number }
      - state-diag: { states: string[], transitions: { from: string, to: string, trigger: string }[] }
      - observability: { gauges: { label: string, current: number, limit: number, status: string }[] }
      - network-topo: { nodes: { id: string, label: string, type: string, status: string, latency: number, x: number, y: number }[], edges: { from: string, to: string }[] }
      - Default: { nodes: { id: string, label: string, type: string, latency?: number }[], edges: { from: string, to: string, label: string }[] }
      
      Responde SOLO con el objeto JSON válido.`,
      config: {
        responseMimeType: "application/json",
      },
    });

    return JSON.parse(response.text || '{}');
  }
}
